﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using PhotoPassword.ViewModels;

namespace PhotoPassword
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            login.Click += login_Click;

            DataContext = new MainViewModel(onGetPhoto, onGetPasswordPoints);

            GetVM().LoginCommand.CanExecuteChanged += LoginCommand_CanExecuteChanged;
        }

        void LoginCommand_CanExecuteChanged(object sender, EventArgs e)
        {
            login.IsEnabled = GetVM().LoginCommand.CanExecute(null);
        }

        void login_Click(object sender, RoutedEventArgs e)
        {
            MakePasswordAttempt();
        }

        private MainViewModel GetVM()
        {
            return (MainViewModel) DataContext;
        }

        private Stream onGetPhoto()
        {
            Stream stm = null;
            var dlg = new OpenFileDialog();
            dlg.Filter = "Image Files (*.jpg)|*.jpg";
            dlg.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            bool? res = dlg.ShowDialog();

            if(((bool)res))
            {
                stm = dlg.OpenFile();
            }
            return stm;
        }

        private void onGetPasswordPoints()
        {
            RecordPassword();
        }

        private void RecordPassword()
        {
            throw new NotImplementedException();
        }

        private void MakePasswordAttempt()
        {
            throw new NotImplementedException();
        }

    }
}

