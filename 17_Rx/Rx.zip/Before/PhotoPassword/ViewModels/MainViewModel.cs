﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Linq;
using MVVM;

namespace PhotoPassword.ViewModels
{
    public class MainViewModel : ViewModel
    {
        private readonly Func<Stream> getPhotoCallback;
        private readonly DelegatingCommand selectPhotoCommand;
        private readonly DelegatingCommand recordPasswordCommand;
        private readonly DelegatingCommand loginCommand;
        private readonly Action getPasswordPoints;

        public IEnumerable<Point> Password
        {
            get { return password; }
            set
            {
                if (value != password)
                {
                    password = value;
                    if (password.Count() != 0)
                    {
                        loginCommand.UpdateCanExecute(password != null);
                        recordPasswordCommand.UpdateCanExecute(false);
                        Prompt = "You may now log in";
                    }
                    OnPropertyChanged();
                    Recording = false;
                }
            }
        }

        public ICommand SelectPhotoCommand { get { return selectPhotoCommand; } }
        public ICommand RecordPasswordCommand { get { return recordPasswordCommand; } }
        public ICommand LoginCommand { get { return loginCommand; } }

        public int PasswordLength { get { return password.Count(); } }

        private bool recording;
        
        public bool Recording
        {
            get { return recording; }
            set
            {
                if (value != recording)
                {
                    recording = value;
                    OnPropertyChanged();
                }
            }
        }



        public MainViewModel(Func<Stream> getPhotoCallback, Action getPasswordPoints)
        {
            this.getPhotoCallback = getPhotoCallback;
            this.getPasswordPoints = getPasswordPoints;
            selectPhotoCommand = new DelegatingCommand(OnSelectPhoto);
            recordPasswordCommand = new DelegatingCommand(OnRecordPassword, false);
            loginCommand = new DelegatingCommand(OnLogin, false);
            Prompt = "Please select photo";
        }

        public IEnumerable<Point> PasswordAttempt
        {
            get { return passwordAttempt; }
            set { passwordAttempt = value; }
        }

        private bool loginSuccessful;

        public bool LoginSuccessful
        {
            get { return loginSuccessful; }
            set
            {
                if (value != loginSuccessful)
                {
                    loginSuccessful = value;
                    OnPropertyChanged();

                    Prompt = value ? "Your log in was successful" : "Your login was unsuccessful";
                }
            }
        }

        private string prompt;

        public string Prompt
        {
            get { return prompt; }
            set
            {
                if (prompt != value)
                {
                    prompt = value;
                    OnPropertyChanged();
                }
            }
        }


        private void OnLogin(object obj)
        {
            LoginSuccessful = PasswordAttempt.FuzzyEquals(password, 5);
        }

        private void OnRecordPassword(object obj)
        {
            getPasswordPoints();
            Recording = true;
        }

        private void OnSelectPhoto(object obj)
        {
            Stream stm = getPhotoCallback();
            var decoder = new JpegBitmapDecoder(stm, BitmapCreateOptions.None, BitmapCacheOption.None);
            var source = decoder.Frames[0];

            Photo = source;
        }

        private BitmapSource photo;
        private IEnumerable<Point> password;
        private IEnumerable<Point> passwordAttempt;

        public BitmapSource Photo
        {
            get { return photo; }
            set
            {
                if (!Equals(photo, value))
                {
                    photo = value;
                    recordPasswordCommand.UpdateCanExecute(photo != null);
                    password = new List<Point>();
                    loginCommand.UpdateCanExecute(false);
                    OnPropertyChanged();
                    Prompt = "Please record password";
                }
            }
        }
        
    }

    static class EqualsExtensions
    {
        public static bool FuzzyEquals(this IEnumerable<Point> source, IEnumerable<Point> other, double tolerance )
        {
            return source.SequenceEqual(other, new FuzzyComparer(tolerance));
        }

        class FuzzyComparer : IEqualityComparer<Point>
        {
            private readonly double tolerance;

            public FuzzyComparer(double tolerance)
            {
                this.tolerance = tolerance;
            }

            public bool Equals(Point x, Point y)
            {
                double distance = GetDistanceBetween(x, y);

                return distance < tolerance;
            }

            private double GetDistanceBetween(Point x, Point y)
            {
                return Math.Sqrt((x.X - y.X)*(x.X - y.X) + (x.Y - y.Y)*(x.Y - y.Y));
            }

            public int GetHashCode(Point obj)
            {
                // rule is if two things are equal 
                // their hash code must be equal
                return 42;
            }
        }

    }
}