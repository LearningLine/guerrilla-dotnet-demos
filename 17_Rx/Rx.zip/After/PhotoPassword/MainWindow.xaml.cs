﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reactive.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using PhotoPassword.ViewModels;

namespace PhotoPassword
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            login.Click += login_Click;

            DataContext = new MainViewModel(onGetPhoto, onGetPasswordPoints);

            GetVM().LoginCommand.CanExecuteChanged += LoginCommand_CanExecuteChanged;
        }

        void LoginCommand_CanExecuteChanged(object sender, EventArgs e)
        {
            login.IsEnabled = GetVM().LoginCommand.CanExecute(null);
        }

        void login_Click(object sender, RoutedEventArgs e)
        {
            MakePasswordAttempt();
        }

       

        private MainViewModel GetVM()
        {
            return (MainViewModel) DataContext;
        }

        private Stream onGetPhoto()
        {
            Stream stm = null;
            var dlg = new OpenFileDialog();
            dlg.Filter = "Image Files (*.jpg)|*.jpg";
            dlg.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            bool? res = dlg.ShowDialog();

            if(((bool)res))
            {
                stm = dlg.OpenFile();
            }
            return stm;
        }

        private void onGetPasswordPoints()
        {
            RecordPassword();
        }

        private void RecordPassword()
        {
            var points = new List<Point>();
            var completeObs = Observable.FromEventPattern<EventArgs>(complete, "Click");
            IDisposable subscription = null;
            subscription = Observable.FromEventPattern<MouseEventArgs>(image, "MouseDown")
                .TakeUntil(completeObs)
                .Subscribe(ep => points.Add(ep.EventArgs.GetPosition(image)), 
                           () =>
                            {
                                GetVM().Password = points.ToList();
                                subscription.Dispose();
                            });
        }

        private void MakePasswordAttempt()
        {
            IDisposable subscription = null;
            List<Point> passwordAttempt = new List<Point>();

            //subscription = Observable.FromEventPattern<MouseEventArgs>(image, "MouseDown")
            //    .TakeWhile(ep => passwordAttempt.Count < GetVM().PasswordLength)
            //    .Subscribe(ep => passwordAttempt.Add(ep.EventArgs.GetPosition(image)), () =>
            //                                                                               {
            //                                                                                   GetVM().PasswordAttempt =
            //                                                                                       passwordAttempt;
            //                                                                                   GetVM().LoginCommand.Execute(null);
            //                                                                                   subscription.Dispose();
            //                                                                               });

            //Observable.FromEventPattern<MouseEventArgs>(image, "MouseDown")
            //    .Buffer(GetVM().PasswordLength)
            //    .Subscribe(eps =>
            //    {
            //        passwordAttempt.AddRange(eps.Select(ep => ep.EventArgs.GetPosition(image)));
            //        GetVM().PasswordAttempt =
            //            passwordAttempt;
            //        GetVM().LoginCommand.Execute(null);
            //    });

            subscription = Observable.FromEventPattern<MouseEventArgs>(image, "MouseDown")
                .Window(GetVM().PasswordLength)
                .Subscribe(ep =>
                               {
                                   IDisposable subsubscription = null;
                    subsubscription = ep.Subscribe(evt => passwordAttempt.Add(evt.EventArgs.GetPosition(image)),
                                 () =>
                                 {
                                     GetVM().PasswordAttempt = passwordAttempt;
                                     GetVM().LoginCommand.Execute(null);
                                     subsubscription.Dispose();
                                     subscription.Dispose();
                                 });
                });
        }
    }
}

