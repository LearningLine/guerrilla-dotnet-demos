﻿using System;
using System.Windows.Input;
namespace MVVM
{
    public class DelegatingCommand : ICommand
    {
        private readonly Action<object> execute;
        private bool canExecute;

        public DelegatingCommand(Action<object> execute)
            :this(execute, true)
        {
        }

        public DelegatingCommand(Action<object> execute, bool canExecute)
        {
            this.canExecute = canExecute;
            this.execute = execute;
        }

        public bool CanExecute(object parameter)
        {
            return canExecute;
        }

        public void UpdateCanExecute(bool newValue)
        {
            if (canExecute != newValue)
            {
                canExecute = newValue;

                CanExecuteChanged(this, EventArgs.Empty);
            }
        }

        public event EventHandler CanExecuteChanged = delegate { };

        public void Execute(object parameter)
        {
            execute(parameter);
        }
    }
}